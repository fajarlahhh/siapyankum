<!-- begin #footer -->
<div id="footer" class="footer">
	&copy; 2019 {{ config("app.name") }} - Bidang Hukum, POLDA NTB
</div>
<!-- end #footer -->
