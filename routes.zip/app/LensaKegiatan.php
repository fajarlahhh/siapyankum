<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LensaKegiatan extends Model
{
    //
    protected $table = 'lensa_kegiatan';
    protected $primaryKey = 'lensa_kegiatan_id';
}
