<!-- begin #footer -->
<div id="footer" class="footer text-light">
	&copy; 2019 {{ config("app.name") }} - Bidang Hukum, POLDA NTB
</div>
<!-- end #footer -->
