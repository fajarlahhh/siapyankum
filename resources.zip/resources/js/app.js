require('jqueryui');
require('./bootstrap');
require('jquery-slimscroll');

window.Vue = require('vue');
window.Cookies = require('js-cookie');
