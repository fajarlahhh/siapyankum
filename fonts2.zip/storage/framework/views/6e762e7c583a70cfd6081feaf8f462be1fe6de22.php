<meta charset="utf-8" />
<title><?php echo e(config("app.name")); ?> <?php echo $__env->yieldContent('title'); ?></title>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
<link rel="icon" href="/assets/img/logo/favicon.png" type="image/gif">
<meta content="Akunting PDAM Giri Menang" name="description" />
<meta content="Andi Fajar Nugraha" name="author" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- ================== BEGIN BASE CSS STYLE ================== -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
<link href="<?php echo e(asset('/assets/css/app.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('/assets/css/jqueryui/jquery-ui.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('/assets/css/default/style.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('/assets/css/default/style-responsive.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('/assets/css/default/theme/default.css" rel="styl')); ?>esheet" id="theme" />
<link href="<?php echo e(asset('/assets/plugins/gritter/css/jquery.gritter.css')); ?>" rel="stylesheet" />
<!-- ================== END BASE CSS STYLE ================== -->

<!-- ================== BEGIN BASE JS ================== -->
<script src="<?php echo e(asset('/assets/plugins/pace/pace.min.js')); ?>"></script>
<!-- ================== END BASE JS ================== -->
<style type="text/css">
	.numbering{
		text-align: right;
	}
	@page  {
	    size: auto;
	}
</style>
<?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH D:\www\yankum-polda-ntb\resources\views/includes/head.blade.php ENDPATH**/ ?>