<?php $__env->startSection('title', ' | Peraturan'); ?>

<?php
    $warna = array('grey','purple','indigo','primary','info','yellow','warning','pink','danger','success','green','lime');
?>

<?php $__env->startSection('content'); ?>
    <h4 class="text-center text-light">Peraturan</h4>
    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/frontend/peraturan/<?php echo e($row->peraturan_jenis_id); ?>" class="col-12 col-sm-12 col-xs-12 col-md-12 col-lg-12 col-xl-12 text-center btn btn-<?php echo e($warna[rand(0, 11)]); ?> btn-lg mb-2" style="line-height: 50px;">
            <h4 class="text-light"><?php echo e(ucfirst($row->peraturan_jenis_nama)); ?></h4>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br>
    <div class="text-center">
        <a href="/frontend/" class="text-center btn btn-inverse">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.default', ['paceTop' => true, 'bodyExtraClass' => 'bg-white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyank/public_html/resources/views/frontend/pages/peraturan/home.blade.php ENDPATH**/ ?>