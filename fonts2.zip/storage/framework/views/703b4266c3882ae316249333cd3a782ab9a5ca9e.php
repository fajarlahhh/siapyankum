

<?php $__env->startSection('title', ' | Jenis Peraturan'); ?>

<?php $__env->startSection('page'); ?>
	<li class="breadcrumb-item active">Jenis Peraturan</li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	<link href="/assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>
	<h1 class="page-header">Jenis Peraturan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
	<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
		<!-- begin panel-heading -->
		<div class="panel-heading">
			<div class="row">
                <div class="col-md-4 col-lg-5 col-xl-3 col-xs-12">
                	<?php if(auth()->check() && auth()->user()->hasRole('user|administrator')): ?>
                    <div class="form-inline">
                        <a href="<?php echo e(route('jenisperaturan.tambah')); ?>" class="btn btn-sm btn-primary"><i class="fas fa-plus"></i> Tambah</a>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-8 col-lg-7 col-xl-9 col-xs-12">
                	<form action="<?php echo e(route('jenisperaturan')); ?>" method="GET" id="frm-cari">
                		<div class="form-inline pull-right">
							<div class="form-group">
								<select class="form-control selectpicker cari" name="tipe" data-live-search="true" data-style="btn-warning" data-width="100%">
									<option value="0" <?php echo e($tipe == '0'? 'selected': ''); ?>>Exist</option>
									<option value="1" <?php echo e($tipe == '1'? 'selected': ''); ?>>Deleted</option>
									<option value="2" <?php echo e($tipe == '2'? 'selected': ''); ?>>All</option>
								</select>
							</div>&nbsp;
							<?php if($tipe != '1'): ?>
		                	<div class="input-group">
								<input type="text" class="form-control cari" name="cari" placeholder="Cari" aria-label="Sizing example input" autocomplete="off" aria-describedby="basic-addon2" value="<?php echo e($cari); ?>">
								<div class="input-group-append">
									 <span class="input-group-text" id="basic-addon2"><i class="fa fa-search"></i></span>
								</div>
							</div>
							<?php endif; ?>
                		</div>
					</form>
                </div>
            </div>

		</div>
		<div class="panel-body">
			<div class="table-responsive">
				<table class="table table-hover">
                    <thead>
						<tr>
							<th>No.</th>
							<th>Jenis Peraturan</th>
							<th class="width-90"></th>
						</tr>
					</thead>
					<tbody>
					    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					        <td><?php echo e(++$i); ?></td>
					        <td><?php echo e($row->peraturan_jenis_nama); ?></td>
					        <td>
					        	<?php if(auth()->check() && auth()->user()->hasRole('user|administrator')): ?>
								<?php if(!$row->deleted_at): ?>
	                            <a href="/jenisperaturan/edit/<?php echo e($row->peraturan_jenis_id); ?>" id='btn-del' class='btn btn-grey btn-xs m-r-3'><i class='fas fa-edit'></i></a>
	                            <a href="javascript:;" onclick="hapus('<?php echo e($row->peraturan_jenis_id); ?>', '<?php echo e($row->peraturan_jenis_nama); ?>')" id='btn-del' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>
	                            <?php else: ?>
	                            <a href="javascript:;" onclick="restore('<?php echo e($row->peraturan_jenis_id); ?>')" id='btn-del' class='btn btn-info btn-xs'><i class='fas fa-undo'></i></a>
	                            <a href="javascript:;" onclick="hapus_permanen('<?php echo e($row->peraturan_jenis_id); ?>', '<?php echo e($row->peraturan_jenis_nama); ?>')" id='btn-del' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>
	                            <?php endif; ?>
	                    		<?php endif; ?>
					        </td>
				      	</tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    </tbody>
				</table>
			</div>
		</div>
		<div class="panel-footer form-inline">
            <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
				<?php echo e($data->links()); ?>

			</div>
			<div class="col-md-6 col-lg-2 col-xl-2 col-xs-12">
				<label class="pull-right">Jumlah Data : <?php echo e($data->total()); ?></label>
			</div>
			This page took <?php echo e((microtime(true) - LARAVEL_START)); ?> seconds to render
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script src="/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script>
		$(".cari").change(function() {
		     $("#frm-cari").submit();
		});

		function hapus(id, nama) {
			swal({
				title: 'Hapus Data',
				text: 'Anda akan menghapus jenis peraturan : ' + nama ,
				icon: 'warning',
				buttons: {
					cancel: {
						text: 'Batal',
						value: null,
						visible: true,
						className: 'btn btn-default',
						closeModal: true,
					},
					confirm: {
						text: 'Ya',
						value: true,
						visible: true,
						className: 'btn btn-danger',
						closeModal: true
					}
				}
			}).then(function(isConfirm) {
		      	if (isConfirm) {
	          		$.ajaxSetup({
					    headers: {
					        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					    }
					});
	          		$.ajax({
	          			url: "/jenisperaturan/hapus/" + id,
	          			type: "POST",
	          			data: {
	          				"_method": 'PATCH',
	          			},
	          			success: function(data){
	          				swal({
						       	title: data['swal_judul'],
						       	text: data['swal_pesan'],
						       	icon: data['swal_tipe'],

						   	}).then(function() {
							    location.reload(true)
							});
	          			},
	          			error: function (xhr, ajaxOptions, thrownError) {
            				swal("Hapus data", xhr.status, "error");
      					}
	          		})
		      	}
		    });
		}

		function hapus_permanen(id, nama) {
			swal({
				title: 'Hapus Data',
				text: 'Anda akan menghapus secara permanen jenis peraturan : ' + nama ,
				icon: 'warning',
				buttons: {
					cancel: {
						text: 'Batal',
						value: null,
						visible: true,
						className: 'btn btn-default',
						closeModal: true,
					},
					confirm: {
						text: 'Ya',
						value: true,
						visible: true,
						className: 'btn btn-danger',
						closeModal: true
					}
				}
			}).then(function(isConfirm) {
		      	if (isConfirm) {
	          		$.ajaxSetup({
					    headers: {
					        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					    }
					});
	          		$.ajax({
	          			url: "/jenisperaturan/hapuspermanen/" + id,
	          			type: "POST",
	          			data: {
	          				"_method": 'DELETE',
	          			},
	          			success: function(data){
	          				swal({
						       	title: data['swal_judul'],
						       	text: data['swal_pesan'],
						       	icon: data['swal_tipe'],

						   	}).then(function() {
							    location.reload(true)
							});
	          			},
	          			error: function (xhr, ajaxOptions, thrownError) {
            				swal("Hapus data", xhr.status, "error");
      					}
	          		})
		      	}
		    });
		}

		function restore(id) {
			$.ajaxSetup({
			    headers: {
			        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    }
			});
      		$.ajax({
      			url: "/jenisperaturan/restore/" + id,
      			type: "POST",
      			data: {
      				"_method": 'PATCH',
      			},
      			success: function(data){
      				swal({
				       	title: data['swal_judul'],
				       	text: data['swal_pesan'],
				       	icon: data['swal_tipe'],

				   	}).then(function() {
					    location.reload(true)
					});
      			},
      			error: function (xhr, ajaxOptions, thrownError) {
    				swal("Restore data", xhr.status, "error");
					}
      		})
		}
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.peraturan.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyankumntb/public_html/resources/views/pages/peraturan/jenisperaturan/index.blade.php ENDPATH**/ ?>