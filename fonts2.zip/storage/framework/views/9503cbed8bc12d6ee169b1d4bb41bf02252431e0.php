

<?php $__env->startSection('title', ' | '.$aksi.' Jenis Peraturan'); ?>

<?php $__env->startPush('css'); ?>
	<link href="/assets/plugins/parsleyjs/src/parsley.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page'); ?>
	<li class="breadcrumb-item">Jenis Peraturan</li>
	<li class="breadcrumb-item active"><?php echo e($aksi); ?> Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
	<h1 class="page-header">Jenis Peraturan <small><?php echo e($aksi); ?> Data</small></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
	<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
		<!-- begin panel-heading -->
		<div class="panel-heading">
			<div class="panel-heading-btn">
                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
            </div>
			<h4 class="panel-title">Form</h4>
		</div>
		<form action="<?php echo e(route('jenisperaturan.'.strtolower($aksi))); ?>" method="post" data-parsley-validate="true" data-parsley-errors-messages-disabled="">
			<?php echo method_field(strtolower($aksi) == 'tambah'? 'POST': 'PUT'); ?>
			<?php echo csrf_field(); ?>
			<div class="panel-body">
				<input type="hidden" name="redirect" value="<?php echo e($back); ?>">
                <?php if($aksi == 'Edit'): ?>
                <input type="hidden" name="peraturan_jenis_id" value="<?php echo e($data->peraturan_jenis_id); ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label class="control-label">Jenis Peraturan</label>
                    <input class="form-control" type="text" name="peraturan_jenis_nama" value="<?php echo e($aksi == 'Edit'? $data->peraturan_jenis_nama: old('peraturan_jenis_nama')); ?>" required data-parsley-minlength="1" data-parsley-maxlength="250" autocomplete="off"  />
                </div>
			</div>
			<div class="panel-footer">
				<?php if(auth()->check() && auth()->user()->hasRole('user|administrator')): ?>
				<input type="submit" value="Simpan" class="btn btn-sm btn-success m-r-3"  />
				<?php endif; ?>
	            <a href="<?php echo e($back); ?>" class="btn btn-sm btn-danger">Batal</a>
	            <div class="pull-right">
					This page took <?php echo e((microtime(true) - LARAVEL_START)); ?> seconds to render
				</div>
	        </div>
		</form>
	</div>
    <?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
		    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      	<li><?php echo e($error); ?></li>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script src="/assets/plugins/parsleyjs/dist/parsley.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.peraturan.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyankumntb/public_html/resources/views/pages/peraturan/jenisperaturan/form.blade.php ENDPATH**/ ?>