

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12" id="messages">
            </div>
        </div>
        <br>
        <div class="text-center">
            <a href="/frontend" class="btn btn-sm btn-primary">Kembali</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.pages.konsultasihukum.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyankumntb/public_html/resources/views/frontend/pages/konsultasihukum/index.blade.php ENDPATH**/ ?>