<!-- begin #page-loader -->
<div id="page-loader" class="fade show"><span class="spinner"></span></div>
<!-- end #page-loader --><?php /**PATH /home/siapyankumntb/public_html/resources/views/frontend/includes/component/page-loader.blade.php ENDPATH**/ ?>