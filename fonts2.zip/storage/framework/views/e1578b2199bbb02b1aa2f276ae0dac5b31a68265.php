<?php $__env->startSection('title', ' | Daftar Konsultasi Hukum'); ?>

<?php $__env->startSection('page'); ?>
	<li class="breadcrumb-item active">Daftar Konsultasi Hukum</li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	<link href="/assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>
	<h1 class="page-header">Daftar Konsultasi Hukum</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
    <form action="/daftarkonsultasihukum/cetak" method="post" data-parsley-validate="true" data-parsley-errors-messages-disabled="" target="_blank">
		<div class="panel-body">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="control-label">Tanggal</label>
                <input type="text" readonly required class="form-control" id="datepicker1" name="tanggal" value="<?php echo e(date('d F Y')); ?>"/>
            </div>
		</div>
        <div class="panel-footer">
            <?php if(auth()->check() && auth()->user()->hasRole('user|administrator')): ?>
            <input type="submit" value="Cetak" class="btn btn-sm btn-success m-r-3"/>
            <?php endif; ?>
            <div class="pull-right">
                This page took <?php echo e((microtime(true) - LARAVEL_START)); ?> seconds to render
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script>

    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'dd MM yyyy',
        orientation: "bottom",
        autoclose: true
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.daftarkonsultasihukum.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyank/public_html/resources/views/pages/daftarkonsultasihukum/index.blade.php ENDPATH**/ ?>