<!-- begin scroll to top btn -->
<a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
<!-- end scroll to top btn -->
<?php /**PATH /home/siapyankumntb/public_html/resources/views/includes/component/scroll-top-btn.blade.php ENDPATH**/ ?>