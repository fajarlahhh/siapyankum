<?php $__env->startSection('title', ' | Peraturan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h4><?php echo $header; ?></h4>
        <br>
        <label><?php echo e($pesan); ?></label>
        <br>
        <a href="<?php echo e(url()->previous()); ?>" class="text-center btn btn-inverse">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>        
		$("#basic-addon2").click(function() {
		     $("#frm-cari").submit();
		});
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.default', ['paceTop' => true, 'bodyExtraClass' => 'bg-white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyank/public_html/resources/views/frontend/pages/eror.blade.php ENDPATH**/ ?>