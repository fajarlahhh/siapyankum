<?php $__env->startSection('title', ' | Lensa Kegiatan'); ?>

<?php
    $warna = array('grey','purple','indigo','primary','info','yellow','warning','pink','danger','success','green','lime');
?>

<?php $__env->startSection('content'); ?>
    <h4 class="text-center text-light">Lensa Kegiatan</h4>
    <br>
    <div class="row">
        <div class="col-12 mb-2">
            <form action="/frontend/lensakegiatan" method="GET" id="frm-cari">
                <div class="input-group">
                    <input type="text" class="form-control cari" name="cari" placeholder="Cari" aria-label="Sizing example input" autocomplete="off" aria-describedby="basic-addon2" value="<?php echo e($cari); ?>">
                    <div class="input-group-append">
                            <span class="input-group-text" id="basic-addon2"><i class="fa fa-search"></i></span>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-12">
            <div class="widget-list widget-list-rounded m-b-30" data-id="widget">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/frontend/lensakegiatan/<?php echo e($row->lensa_kegiatan_id); ?>" class="widget-list-item bg-<?php echo e($warna[rand(0, 11)]); ?>">
                    <div class="widget-list-content">
                        <h4 class="widget-list-title"><?php echo e($row->lensa_kegiatan_judul); ?></h4>
                    </div>
                    <div class="widget-list-action text-right">
                        <i class="fa fa-angle-right fa-lg text-muted"></i>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-12">
            <?php echo e($data->links()); ?>

        </div>
        <div class="col-12 text-center">
            <label class=" text-light">Jumlah Data : <?php echo e($data->total()); ?></label>
        </div>
    </div>
    <div class="text-center">
        <a href="/frontend/" class="text-center btn btn-inverse">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
		$("#basic-addon2").click(function() {
		     $("#frm-cari").submit();
		});
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.default', ['paceTop' => true, 'bodyExtraClass' => 'bg-white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyank/public_html/resources/views/frontend/pages/lensakegiatan/list.blade.php ENDPATH**/ ?>