<?php $__env->startSection('title', '500 Error Page'); ?>

<?php $__env->startSection('content'); ?>
	<!-- begin error -->
	<div class="error">
		<div class="error-code m-b-10">500</div>
		<div class="error-content">
			<div class="error-message">Server Error</div>
			<div>
				<a href="<?php echo e(url()->previous()); ?>" class="btn btn-success p-l-20 p-r-20">Go Back</a>
			</div>
		</div>
	</div>
	<!-- end error -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty', ['paceTop' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\siapyankum\resources\views/errors/500.blade.php ENDPATH**/ ?>