<?php $__env->startSection('title', ' | Bantuan Hukum / Perdata'); ?>

<?php $__env->startPush('css'); ?>
	<link href="/assets/plugins/parsleyjs/src/parsley.css" rel="stylesheet" />
	<link href="/assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" />
	<link href="/assets/plugins/bootstrap3-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page'); ?>
	<li class="breadcrumb-item">Perdata</li>
	<li class="breadcrumb-item active"><?php echo e($aksi); ?> Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
	<h1 class="page-header">Bantuan Hukum / Perdata <small><?php echo e($aksi); ?> Data</small></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subcontent'); ?>
	<div class="panel panel-inverse" data-sortable-id="form-stuff-1">
		<!-- begin panel-heading -->
		<div class="panel-heading">
			<div class="panel-heading-btn">
                <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
            </div>
			<h4 class="panel-title">Form</h4>
		</div>
		<form action="<?php echo e(route('perdata.'.strtolower($aksi))); ?>" method="post" data-parsley-validate="true" data-parsley-errors-messages-disabled="">
			<?php echo csrf_field(); ?>
			<div class="panel-body">
                <?php if($data->proses->count() == 3 && $data->proses[2]->bantuan_hukum_proses_status == "PUTUSAN SIDANG"): ?>
                <div class="note note-primary m-b-15">
                    <input type="hidden" name="redirect" value="<?php echo e($back); ?>">
                    <input type="hidden" name="bantuan_hukum_id" value="<?php echo e($data->bantuan_hukum_id); ?>" required>
                    <div class="form-group">
                        <label class="control-label">No. Laporan</label>
                        <input class="form-control" type="text" name="bantuan_hukum_laporan_nomor" value="<?php echo e($data->bantuan_hukum_laporan_nomor); ?>" required data-parsley-minlength="1" data-parsley-maxlength="250" autocomplete="off" readonly />
                    </div>
                    <div class="form-group">
                        <label class="control-label">Tanggal</label>
                        <input class="form-control" type="text" name="bantuan_hukum_tanggal" value="<?php echo e(date('d F Y', strtotime($data->bantuan_hukum_tanggal))); ?>" required data-parsley-minlength="1" data-parsley-maxlength="250" autocomplete="off" readonly />
                    </div>
                    <div class="form-group">
                        <label class="control-label">Judul</label>
                        <textarea class="textarea form-control" name="bantuan_hukum_judul" rows="12" readonly><?php echo e($data->bantuan_hukum_judul); ?>

                        </textarea>
                    </div>
                </div>
                <?php else: ?>
				<div class="row">
					<div class="col-md-4">
                        <div class="note note-primary m-b-15">
                            <input type="hidden" name="redirect" value="<?php echo e($back); ?>">
                            <input type="hidden" name="bantuan_hukum_id" value="<?php echo e($data->bantuan_hukum_id); ?>" required>
                            <div class="form-group">
                                <label class="control-label">No. Laporan</label>
                                <input class="form-control" type="text" name="bantuan_hukum_laporan_nomor" value="<?php echo e($data->bantuan_hukum_laporan_nomor); ?>" required data-parsley-minlength="1" data-parsley-maxlength="250" autocomplete="off" readonly />
                            </div>
                            <div class="form-group">
                                <label class="control-label">Tanggal</label>
                                <input class="form-control" type="text" name="bantuan_hukum_tanggal" value="<?php echo e(date('d F Y', strtotime($data->bantuan_hukum_tanggal))); ?>" required data-parsley-minlength="1" data-parsley-maxlength="250" autocomplete="off" readonly />
                            </div>
                            <div class="form-group">
                                <label class="control-label">Judul</label>
                                <textarea class="textarea form-control" name="bantuan_hukum_judul" rows="12" readonly><?php echo e($data->bantuan_hukum_judul); ?>

                                </textarea>
                            </div>
                        </div>
					</div>
					<div class="col-md-8">
                        <div class="form-group">
                            <label class="control-label">Status</label>
                            <select class="form-control selectpicker" style="width : 100%" name="bantuan_hukum_proses_status" id="bantuan_hukum_proses_status" data-style="btn-info" data-width="100%">
                                <option value="DALAM PROSES">DALAM PROSES</option>
                                <option value="PROSES SIDANG">PROSES SIDANG</option>
                                <option value="PUTUSAN SIDANG">PUTUSAN SIDANG</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Tanggal</label>
                            <input type="text" readonly required class="form-control" id="datepicker1" name="bantuan_hukum_proses_tanggal" value="<?php echo e(date('d F Y', strtotime($aksi == 'Edit'? $data->bantuan_hukum_proses_tanggal: (old('bantuan_hukum_proses_tanggal')? old('bantuan_hukum_proses_tanggal'): now())))); ?>"/>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Detail</label>
                            <textarea class="textarea form-control" id="wysihtml5" name="bantuan_hukum_proses_deskripsi" placeholder="Enter text ..." rows="12">
                                <?php echo e($aksi == 'Edit'? $data->bantuan_hukum_proses_deskripsi: old('bantuan_hukum_proses_deskripsi')); ?>

                            </textarea>
                        </div>
					</div>
                </div>
                <?php endif; ?>
                <hr>
                <h4>History</h4>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Detail</th>
                                <th class="width-90"></th>
                            </tr>
                            <?php
                                $i = 0;
                                $jumlah = $data->proses->count();
                            ?>
                            <?php $__currentLoopData = $data->proses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($row->bantuan_hukum_proses_tanggal)->isoFormat('LL')); ?></td>
                                <td><?php echo e($row->bantuan_hukum_proses_status); ?><br><small><?php echo e($row->operator.', '.\Carbon\Carbon::parse($row->created_at)->isoFormat('LL')); ?></small></td>
                                <td><?php echo $row->bantuan_hukum_proses_deskripsi; ?></td>
                                <td>
                                    <a href="javascript:;" onclick="hapus('<?php echo e($row->bantuan_hukum_id); ?>', '<?php echo e($row->bantuan_hukum_proses_status); ?>', '<?php echo e($data->bantuan_hukum_laporan_nomor); ?>', '<?php echo e($row->bantuan_hukum_proses_tanggal); ?>')" id='btn-del' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>
                    </table>
                </div>
			</div>
			<div class="panel-footer">
				<?php if(auth()->check() && auth()->user()->hasRole('user|administrator')): ?>
                <?php if($data->proses->count() < 3): ?>
                <input type="submit" value="Simpan" class="btn btn-sm btn-success m-r-3"/>
                <?php endif; ?>
				<?php endif; ?>
	            <a href="<?php echo e($back); ?>" class="btn btn-sm btn-danger">Batal</a>
	            <div class="pull-right">
					This page took <?php echo e((microtime(true) - LARAVEL_START)); ?> seconds to render
				</div>
	        </div>
		</form>
	</div>
    <?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
		    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      	<li><?php echo e($error); ?></li>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script src="/assets/plugins/parsleyjs/dist/parsley.js"></script>
	<script src="/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	<script src="/assets/plugins/bootstrap3-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
        $('#wysihtml5').wysihtml5({
            selected: 0,
            theme: 'default',
            transitionEffect:'',
            transitionSpeed: 0,
            useURLhash: false,
            showStepURLhash: false,
            toolbarSettings: {
                toolbarPosition: 'bottom'
            }
        });

		$('#datepicker1').datepicker({
			todayHighlight: true,
			format: 'dd MM yyyy',
			orientation: "bottom",
			autoclose: true
		});

		function hapus(id, status, nama, tanggal) {
			swal({
				title: 'Hapus Data',
				text: 'Anda akan menghapus proses bantuan hukum perdata : ' + nama + ' dengan status : ' + status,
				icon: 'warning',
				buttons: {
					cancel: {
						text: 'Batal',
						value: null,
						visible: true,
						className: 'btn btn-default',
						closeModal: true,
					},
					confirm: {
						text: 'Ya',
						value: true,
						visible: true,
						className: 'btn btn-danger',
						closeModal: true
					}
				}
			}).then(function(isConfirm) {
		      	if (isConfirm) {
	          		$.ajaxSetup({
					    headers: {
					        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					    }
					});
	          		$.ajax({
	          			url: "/perdata/hapusproses/" + id + "/" + status + "/" + tanggal,
	          			type: "POST",
	          			data: {
	          				"_method": 'DELETE',
	          			},
	          			success: function(data){
	          				swal({
						       	title: data['swal_judul'],
						       	text: data['swal_pesan'],
						       	icon: data['swal_tipe'],

						   	}).then(function() {
							    location.reload(true)
							});
	          			},
	          			error: function (xhr, ajaxOptions, thrownError) {
            				swal("Hapus data", xhr.status, "error");
      					}
	          		})
		      	}
		    });
		}
	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.bantuanhukum.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyankumntb/public_html/resources/views/pages/bantuanhukum/perdata/proses.blade.php ENDPATH**/ ?>