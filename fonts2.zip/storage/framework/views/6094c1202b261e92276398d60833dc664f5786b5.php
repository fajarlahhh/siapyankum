<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <style type="text/css">
        table {
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #e2e7eb;
            padding: 3px;
        }
        @page  {
            header: page-header;
            footer: page-footer;
        }
        body{
            font-size: 12px;
            font-family: 'Open Sans',"Helvetica Neue",Helvetica,Arial,sans-serif;
        }
    </style>
</head>
<body>
	<center>
        <h5>DAFTAR KONSULTASI HUKUM <br><small><?php echo e(date('d M Y', strtotime($tanggal))); ?></small></h5>
        <hr>
    </center>
    <table style="width:100%">
        <tr>
            <th>No.</th>
            <th>Nama</th>
            <th>Pesan</th>
            <th>Waktu</th>
        </tr>
        <?php
            $no=1;
        ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no); ?></td>
            <td><?php echo e($row->pengguna_nama); ?> - <?php echo e($row->pengguna_id); ?></td>
            <td><?php echo e($row->chat_pesan); ?></td>
            <td><?php echo e($row->created_at); ?></td>
        </tr>
        <?php
            $no++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <script src="<?php echo e(asset('/assets/js/bundle.js')); ?>"></script>
    <script>
        window.print();
    </script>
</body>
</html>
<?php /**PATH /home/siapyank/public_html/resources/views/pages/daftarkonsultasihukum/cetak.blade.php ENDPATH**/ ?>