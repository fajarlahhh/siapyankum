<!-- begin #page-loader -->
<div id="page-loader" class="fade show"><span class="spinner"></span></div>
<!-- end #page-loader --><?php /**PATH D:\www\yankum-polda-ntb\resources\views/includes/component/page-loader.blade.php ENDPATH**/ ?>