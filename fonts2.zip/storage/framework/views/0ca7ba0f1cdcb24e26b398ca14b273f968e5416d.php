

<?php $__env->startSection('title', ' | Pendapat & Saran Hukum'); ?>

<?php
    $warna = array('secondary ','purple','indigo','primary','info','yellow','warning','pink','danger','success','green','lime');
?>

<?php $__env->startSection('content'); ?>
    <h4 class="text-center text-light">Pendapat & Saran Hukum</h4>
    <br>
    <div class="note note-<?php echo e($warna[rand(0, 11)]); ?> m-b-15" style="padding: 0px !important">
        <table class="table">
            <tbody>
                <tr>
                    <th width="105">No. Laporan</th>
                    <td width="5">:</td>
                    <td><?php echo e($data->pendapat_saran_laporan_nomor); ?></td>
                </tr>
                <tr>
                    <th>Tanggal</th>
                    <td>:</td>
                    <td><?php echo e(\Carbon\Carbon::parse($data->pendapat_saran_tanggal)->isoFormat('LL')); ?></td>
                </tr>
                <tr>
                    <th>Judul</th>
                    <td>:</td>
                    <td><?php echo e($data->pendapat_saran_judul); ?></td>
                </tr>
                <tr>
                    <td colspan="3"><?php echo $data->pendapat_saran_keterangan; ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="note note-<?php echo e($warna[rand(0, 11)]); ?> m-b-15">
        <h5>Status : <?php echo e($data->proses->last()->pendapat_saran_proses_status); ?></h5>
        <label><?php echo $data->proses->last()->pendapat_saran_proses_deskripsi; ?></label>
    </div>
    <br>
    <div class="text-center">
        <a href="/frontend/pendapatsaran" class="text-center btn btn-inverse">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.default', ['paceTop' => true, 'bodyExtraClass' => 'bg-white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyankumntb/public_html/resources/views/frontend/pages/pendapatsaranhukum/tampil.blade.php ENDPATH**/ ?>