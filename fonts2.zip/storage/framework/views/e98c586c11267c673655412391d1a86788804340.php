<?php
	$headerClass = (!empty($headerInverse)) ? 'navbar-inverse ' : 'navbar-default ';
	$headerMenu = (!empty($headerMenu)) ? $headerMenu : '';
	$hiddenSearch = (!empty($headerLanguageBar)) ? 'hidden-xs' : '';
	$headerMegaMenu = (!empty($headerMegaMenu)) ? $headerMegaMenu : '';
	$headerTopMenu = (!empty($headerTopMenu)) ? $headerTopMenu : '';
?>
<!-- begin #header -->
<div id="header" class="header <?php echo e($headerClass); ?>">
	<!-- begin navbar-header -->
	<div class="navbar-header">
	    <a href="/" class="navbar-brand">
	      	<b>POLDA NTB</b> <?php echo e(config("app.name")); ?>

	    </a>
	    <button type="button" class="navbar-toggle" data-click="sidebar-toggled">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
	    </button>
  	</div>
	<!-- end navbar-header -->

	<!-- begin header-nav -->
	<ul class="navbar-nav navbar-right">
        <li class="">
            <a href="/konsultasihukum" data-toggle="" class="f-s-14">
                <i class="fa fa-comments"></i>
                <span class="label" id="pending-notif">0</span>
            </a>
        </li>
		<li class="dropdown navbar-user">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">
				<img src="/assets/img/user/user.png" alt="" />
				<span class="d-none d-md-inline"><?php echo e(Auth::user()->pengguna_nama); ?></span> <b class="caret"></b>
			</a>
			<div class="dropdown-menu dropdown-menu-right">
				<a href="#modal-katasandi" id="btn-password" class="dropdown-item" data-toggle="modal">Ganti Kata Sandi</a>
				<div class="dropdown-divider"></div>
				<a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Log Out')); ?></a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
			</div>
		</li>
	</ul>
	<!-- end header navigation right -->
</div>
<!-- end #header -->
<div class="modal fade" id="modal-katasandi">
	<div class="modal-dialog">
		<div id="modal-password"></div>
	</div>
</div>

<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript">
		$("#btn-password").click(function(){
	    	$("#modal-password").load("/gantisandi");
	      	$.getScript("/assets/plugins/bootstrap-show-password/dist/bootstrap-show-password.min.js");
	      	$.getScript("/assets/plugins/parsleyjs/dist/parsley.js");
	  	});
	</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/siapyankumntb/public_html/resources/views/includes/header.blade.php ENDPATH**/ ?>