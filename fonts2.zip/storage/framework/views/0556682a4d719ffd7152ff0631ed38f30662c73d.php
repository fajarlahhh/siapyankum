<!-- begin #footer -->
<div id="footer" class="footer text-light">
	&copy; 2019 <?php echo e(config("app.name")); ?> - Bidang Hukum, POLDA NTB
</div>
<!-- end #footer -->
<?php /**PATH /home/siapyankumntb/public_html/resources/views/frontend/includes/footer.blade.php ENDPATH**/ ?>