<?php $__env->startSection(config("app.name"), ' | Peraturan'); ?>

<?php $__env->startSection('content'); ?>
	<!-- begin breadcrumb -->
	<ol class="breadcrumb pull-right">
		<li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
		<li class="breadcrumb-item"><a href="javascript:;">Peraturan</a></li>
		<?php echo $__env->yieldContent('page'); ?>
	</ol>
	<!-- end breadcrumb -->
	<!-- begin page-header -->
	<?php echo $__env->yieldContent('header'); ?>
	<!-- end page-header -->
	<?php echo $__env->yieldContent('subcontent'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script src="/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siapyank/public_html/resources/views/pages/peraturan/main.blade.php ENDPATH**/ ?>