
window.swal = require('sweetalert');