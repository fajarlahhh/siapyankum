@extends('frontend.pages.konsultasihukum.app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12" id="messages">
            </div>
        </div>
        <br>
        <div class="text-center">
            <a href="/frontend" class="btn btn-sm btn-primary">Kembali</a>
        </div>
    </div>
@endsection
