<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Litcatkum extends Model
{
  //
  protected $table = 'litcatkum';
  protected $primaryKey = 'litcatkum_id';

}
